package ex3;

public class Enunciat {
/*
    1. Copia la classe HastTable de l'exercici anterior així com els seus jocs de proves dins aquest package i modifica
       el codi font perquè el faci servir (canvia "ex1" per "ex2" allà on toqui).

    2. Aplica-hi el mètode de refacció "extracció de classe" i explica per què creus que ha sigut convenient
       aplicar-los.

    3. Aplica-hi el mètode de refacció "extracció de mètode" i explica per què creus que ha sigut convenient
       aplicar-los.

    4. Torna a executar els jocs de proves per a comprovar que el codi segueix funcionant correctament, ja que al
       fer-hi canvis refactoritzant es corre el risc de trencar el codi.

*/
}
