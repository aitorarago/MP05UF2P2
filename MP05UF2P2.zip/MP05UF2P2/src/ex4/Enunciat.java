package ex4;

public class Enunciat {
/*
    1. Copia la classe HastTable de l'exercici anterior així com els seus jocs de proves dins aquest package i modifica
       el codi font perquè el faci servir (canvia "ex2" per "ex3" allà on toqui).

    2. Fes que la taula de hash permeti emmagatzemar altres tipus de dades (object) i no només strings, per això et
       caldrà modificar el tipus de dada que emmagatzema la classe "HashEntry" així com alguns paràmetres dels mètodes
       que la fan servir.

    3. Explica els canvis que has hagut de fer, però NO ESBORRIS CODI, tan sols comenta'l
       perquè es pugui veure el codi antic i el codi nou.

    4. Adapta els jocs de proves perquè comprovin que els canvis que has fet són correctes, ja que només estan provant
       d'emmagatzemar strings i ara es permet emmagatzemar qualsevol tipus de dada (pots provar amb algunes primitives).
*/
}
